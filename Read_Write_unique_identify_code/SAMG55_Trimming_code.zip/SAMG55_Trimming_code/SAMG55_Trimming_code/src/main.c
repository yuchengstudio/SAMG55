/**
 * \file
 *
 * \brief Empty user application template
 *
 */

/**
 * \mainpage User Application template doxygen documentation
 *
 * \par Empty user application template
 *
 * This is a bare minimum user application template.
 *
 * For documentation of the board, go \ref group_common_boards "here" for a link
 * to the board-specific documentation.
 *
 * \par Content
 *
 * -# Include the ASF header files (through asf.h)
 * -# Minimal main function that starts with a call to board_init()
 * -# Basic usage of on-board LED and button
 * -# "Insert application code here" comment
 *
 */

/*
 * Include header files for all drivers that have been imported from
 * Atmel Software Framework (ASF).
 */
/*
 * Support and FAQ: visit <a href="http://www.atmel.com/design-support/">Atmel Support</a>
 */
#include <asf.h>


uint32_t unique_id[32];
uint32_t trim_value;
uint8_t trim_value1;
//uint32_t trim_value2;
//uint32_t trim_value3;

void supc_set_trim_user(Supc *p_supc, uint8_t value)
{
	p_supc->SUPC_PWMR = SUPC_PWMR_KEY_PASSWD | SUPC_PWMR_ECPWRS_USER | (value << 8);
}

int main (void)
{
	uint32_t x = 0;
	
	board_init();
	
	sysclk_init();
	/* Get the trim value from unique ID area */
	efc_perform_read_sequence(EFC, EFC_FCMD_STUI, EFC_FCMD_SPUI,unique_id, 32);
	trim_value = (unique_id[16]);
	trim_value1 =   (trim_value & 0x0f) << 1; 
	supc_set_trim_user(SUPC, trim_value1);
	x = SUPC->SUPC_PWMR;
	
	while(1);

}


